const destinations = [
  {
    id: 1,
    name: "Hạ Long",
    country: "Việt Nam",
    description: "Vịnh Hạ Long với những hòn đảo đá vôi kỳ vĩ",
    image: "/ha-long-bay-vietnam-limestone-islands.jpg",
    rating: 4.8,
  },
  {
    id: 2,
    name: "Bali",
    country: "Indonesia",
    description: "Thiên đường nhiệt đới với bãi biển trắng",
    image: "/bali-beach-tropical-paradise.jpg",
    rating: 4.7,
  },
  {
    id: 3,
    name: "Tokyo",
    country: "Nhật Bản",
    description: "Thành phố hiện đại kết hợp truyền thống",
    image: "/tokyo-japan-modern-city-night.jpg",
    rating: 4.9,
  },
  {
    id: 4,
    name: "Paris",
    country: "Pháp",
    description: "Thành phố tình yêu với kiến trúc cổ điển",
    image: "/paris-france-eiffel-tower-romantic.jpg",
    rating: 4.8,
  },
]

export default function Destinations() {
  return (
    <section id="destinations" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Điểm Đến Nổi Bật</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Khám phá những địa điểm du lịch tuyệt vời nhất trên thế giới
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {destinations.map((dest) => (
            <div
              key={dest.id}
              className="group cursor-pointer rounded-lg overflow-hidden bg-card hover:shadow-lg transition-all duration-300"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={dest.image || "/placeholder.svg"}
                  alt={dest.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-lg font-bold text-card-foreground">{dest.name}</h3>
                    <p className="text-sm text-muted-foreground">{dest.country}</p>
                  </div>
                  <div className="flex items-center gap-1 bg-secondary/20 px-2 py-1 rounded">
                    <span className="text-sm font-semibold text-secondary-foreground">★</span>
                    <span className="text-sm font-semibold text-secondary-foreground">{dest.rating}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-4">{dest.description}</p>
                <button className="w-full py-2 bg-primary text-primary-foreground rounded hover:bg-primary/90 transition font-medium text-sm">
                  Xem Chi Tiết
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
