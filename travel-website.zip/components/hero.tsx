export default function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url(/placeholder.svg?height=1080&width=1920&query=beautiful-mountain-landscape-sunset)",
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 max-w-3xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 text-balance">Khám Phá Thế Giới</h1>
        <p className="text-xl md:text-2xl mb-8 text-white/90 text-balance">
          Hành trình tuyệt vời đang chờ bạn. Cùng chúng tôi khám phá những điểm đến tuyệt đẹp trên thế giới.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition font-semibold text-lg">
            Bắt Đầu Ngay
          </button>
          <button className="px-8 py-3 bg-white/20 text-white rounded-lg hover:bg-white/30 transition font-semibold text-lg border border-white/50">
            Tìm Hiểu Thêm
          </button>
        </div>
      </div>
    </section>
  )
}
