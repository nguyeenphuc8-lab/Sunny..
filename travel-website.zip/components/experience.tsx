const experiences = [
  {
    icon: "🏔️",
    title: "Phiêu Lưu",
    description: "Những trải nghiệm phiêu lưu kích thích với các hoạt động ngoài trời",
  },
  {
    icon: "🍽️",
    title: "Ẩm Thực",
    description: "Khám phá những món ăn đặc sắc từ các nền văn hóa khác nhau",
  },
  {
    icon: "🏛️",
    title: "Văn Hóa",
    description: "Tìm hiểu lịch sử và văn hóa của các địa phương",
  },
  {
    icon: "🌅",
    title: "Thiên Nhiên",
    description: "Thưởng ngoạn những cảnh quan thiên nhiên tuyệt đẹp",
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-20 px-4 bg-secondary/10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Trải Nghiệm Độc Đáo</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Chúng tôi cung cấp những trải nghiệm du lịch không thể quên
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {experiences.map((exp, idx) => (
            <div key={idx} className="text-center p-6 rounded-lg bg-background hover:shadow-md transition-shadow">
              <div className="text-5xl mb-4">{exp.icon}</div>
              <h3 className="text-xl font-bold text-foreground mb-3">{exp.title}</h3>
              <p className="text-muted-foreground">{exp.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
