export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold">✈</span>
              </div>
              <span className="text-xl font-bold">Wanderlust</span>
            </div>
            <p className="text-background/80">Khám phá thế giới cùng chúng tôi</p>
          </div>

          <div>
            <h4 className="font-bold mb-4">Công Ty</h4>
            <ul className="space-y-2 text-background/80">
              <li>
                <a href="#" className="hover:text-background transition">
                  Về Chúng Tôi
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  Tin Tức
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  Sự Nghiệp
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Hỗ Trợ</h4>
            <ul className="space-y-2 text-background/80">
              <li>
                <a href="#" className="hover:text-background transition">
                  Trợ Giúp
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  Liên Hệ
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4">Theo Dõi</h4>
            <ul className="space-y-2 text-background/80">
              <li>
                <a href="#" className="hover:text-background transition">
                  Facebook
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  Instagram
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-background transition">
                  Twitter
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 pt-8 text-center text-background/80">
          <p>&copy; 2025 Wanderlust. Tất cả quyền được bảo lưu.</p>
        </div>
      </div>
    </footer>
  )
}
